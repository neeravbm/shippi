<?php

/* {# inline_template_start #}<div class="row  margin-bottom-20">
            <div class="col-lg-4 sm-margin-bottom-20">
              <div class="thumbnail-style">
                    <div class="thumbnail-img">
                          <div class="overflow-hidden">
                               {{ field_class_image }}
                          </div>
                    </div>
                </div>            
            </div>
            <div class="col-lg-8 sm-margin-bottom-20">
                <div class="news-v3">
                    <h2>{{ title }}</h2>
                    <p>{{ body }}</p>
                    <a href="/payment" class="btn-u" hreflang="en">Payment Details</a> <a href="/tos" class="btn-u" hreflang="en">Terms & Conditions</a>
                </div>
                
             <!-- <p> {{ view_node }} </p> --> 
            </div>
        </div> */
class __TwigTemplate_c57878bbf3069d353b3644f30060212e4e6882f23da7e2ac6daade04bee936c2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<div class=\"row  margin-bottom-20\">
            <div class=\"col-lg-4 sm-margin-bottom-20\">
              <div class=\"thumbnail-style\">
                    <div class=\"thumbnail-img\">
                          <div class=\"overflow-hidden\">
                               ";
        // line 6
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["field_class_image"]) ? $context["field_class_image"] : null), "html", null, true));
        echo "
                          </div>
                    </div>
                </div>            
            </div>
            <div class=\"col-lg-8 sm-margin-bottom-20\">
                <div class=\"news-v3\">
                    <h2>";
        // line 13
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["title"]) ? $context["title"] : null), "html", null, true));
        echo "</h2>
                    <p>";
        // line 14
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["body"]) ? $context["body"] : null), "html", null, true));
        echo "</p>
                    <a href=\"/payment\" class=\"btn-u\" hreflang=\"en\">Payment Details</a> <a href=\"/tos\" class=\"btn-u\" hreflang=\"en\">Terms & Conditions</a>
                </div>
                
             <!-- <p> ";
        // line 18
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["view_node"]) ? $context["view_node"] : null), "html", null, true));
        echo " </p> --> 
            </div>
        </div>";
    }

    public function getTemplateName()
    {
        return "{# inline_template_start #}<div class=\"row  margin-bottom-20\">
            <div class=\"col-lg-4 sm-margin-bottom-20\">
              <div class=\"thumbnail-style\">
                    <div class=\"thumbnail-img\">
                          <div class=\"overflow-hidden\">
                               {{ field_class_image }}
                          </div>
                    </div>
                </div>            
            </div>
            <div class=\"col-lg-8 sm-margin-bottom-20\">
                <div class=\"news-v3\">
                    <h2>{{ title }}</h2>
                    <p>{{ body }}</p>
                    <a href=\"/payment\" class=\"btn-u\" hreflang=\"en\">Payment Details</a> <a href=\"/tos\" class=\"btn-u\" hreflang=\"en\">Terms & Conditions</a>
                </div>
                
             <!-- <p> {{ view_node }} </p> --> 
            </div>
        </div>";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 18,  83 => 14,  79 => 13,  69 => 6,  62 => 1,);
    }
}
/* {# inline_template_start #}<div class="row  margin-bottom-20">*/
/*             <div class="col-lg-4 sm-margin-bottom-20">*/
/*               <div class="thumbnail-style">*/
/*                     <div class="thumbnail-img">*/
/*                           <div class="overflow-hidden">*/
/*                                {{ field_class_image }}*/
/*                           </div>*/
/*                     </div>*/
/*                 </div>            */
/*             </div>*/
/*             <div class="col-lg-8 sm-margin-bottom-20">*/
/*                 <div class="news-v3">*/
/*                     <h2>{{ title }}</h2>*/
/*                     <p>{{ body }}</p>*/
/*                     <a href="/payment" class="btn-u" hreflang="en">Payment Details</a> <a href="/tos" class="btn-u" hreflang="en">Terms & Conditions</a>*/
/*                 </div>*/
/*                 */
/*              <!-- <p> {{ view_node }} </p> --> */
/*             </div>*/
/*         </div>*/
