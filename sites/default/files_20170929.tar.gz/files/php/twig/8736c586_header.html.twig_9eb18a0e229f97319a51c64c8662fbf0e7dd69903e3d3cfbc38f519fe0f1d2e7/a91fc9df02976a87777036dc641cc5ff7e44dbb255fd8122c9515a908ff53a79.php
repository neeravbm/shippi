<?php

/* themes/shippis/partials/header.html.twig */
class __TwigTemplate_17ac2de72b63e169577772da03727dead14d58fc1f7f82c7d357235564806287 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array("t" => 2);
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array(),
                array('t'),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 2
        echo "<header id=\"header\" class=\"header\" role=\"banner\" aria-label=\"";
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->renderVar(t("Site header")));
        echo "\">
    <div class=\"section layout-container clearfix\">
        <div class=\"container container-fluid\">
            <div class=\"row\">
                <div class=\"col-xs-12 col-md-4 col-sm-12\">
                    <div class=\"\">
                        ";
        // line 8
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "header", array()), "html", null, true));
        echo "
                    </div>
                </div>
                <div class=\"col-xs-12 col-md-8\">
                    <div class=\"row\">
                        <div class=\"topbar\">
                            ";
        // line 14
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "secondary_menu", array()), "html", null, true));
        echo "
                        </div>
                        <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-responsive-collapse\" aria-expanded=\"false\">
                            <span class=\"sr-only\">Toggle navigation</span>
                            <span class=\"fa fa-bars\"></span>
                        </button>
                    </div>
                    <div class=\"row\">
                        <div class=\"navbar-collapse mega-menu navbar-responsive-collapse collapse\">
                            ";
        // line 23
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "primary_menu", array()), "html", null, true));
        echo "
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</header>
";
    }

    public function getTemplateName()
    {
        return "themes/shippis/partials/header.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  74 => 23,  62 => 14,  53 => 8,  43 => 2,);
    }
}
/* {#Main Site Header Starts#}*/
/* <header id="header" class="header" role="banner" aria-label="{{ 'Site header'|t}}">*/
/*     <div class="section layout-container clearfix">*/
/*         <div class="container container-fluid">*/
/*             <div class="row">*/
/*                 <div class="col-xs-12 col-md-4 col-sm-12">*/
/*                     <div class="">*/
/*                         {{ page.header }}*/
/*                     </div>*/
/*                 </div>*/
/*                 <div class="col-xs-12 col-md-8">*/
/*                     <div class="row">*/
/*                         <div class="topbar">*/
/*                             {{ page.secondary_menu }}*/
/*                         </div>*/
/*                         <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-responsive-collapse" aria-expanded="false">*/
/*                             <span class="sr-only">Toggle navigation</span>*/
/*                             <span class="fa fa-bars"></span>*/
/*                         </button>*/
/*                     </div>*/
/*                     <div class="row">*/
/*                         <div class="navbar-collapse mega-menu navbar-responsive-collapse collapse">*/
/*                             {{ page.primary_menu }}*/
/*                         </div>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/* */
/*     </div>*/
/* </header>*/
/* {#Main Site Header Ends#}*/
/* */
