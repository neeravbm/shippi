<?php

/* {# inline_template_start #}<div class="thumbnail-style">
                	<div class="thumbnail-img">
                              <div class="overflow-hidden">
                                     {{ field_gallery_image }} 
                               </div>
                        </div>
                        <div class="text-align-center">
                        {{ title }}<br>
                        <div class="latin_name">
                               <em>{{ field_scientific_name }}</em>
                       </div>
                    </div>
  </div> */
class __TwigTemplate_b65332df69d609a09b813841f2f37237f5844ed56be74bc9a062deed33bcc6db extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<div class=\"thumbnail-style\">
                \t<div class=\"thumbnail-img\">
                              <div class=\"overflow-hidden\">
                                     ";
        // line 4
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["field_gallery_image"]) ? $context["field_gallery_image"] : null), "html", null, true));
        echo " 
                               </div>
                        </div>
                        <div class=\"text-align-center\">
                        ";
        // line 8
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["title"]) ? $context["title"] : null), "html", null, true));
        echo "<br>
                        <div class=\"latin_name\">
                               <em>";
        // line 10
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["field_scientific_name"]) ? $context["field_scientific_name"] : null), "html", null, true));
        echo "</em>
                       </div>
                    </div>
  </div>";
    }

    public function getTemplateName()
    {
        return "{# inline_template_start #}<div class=\"thumbnail-style\">
                \t<div class=\"thumbnail-img\">
                              <div class=\"overflow-hidden\">
                                     {{ field_gallery_image }} 
                               </div>
                        </div>
                        <div class=\"text-align-center\">
                        {{ title }}<br>
                        <div class=\"latin_name\">
                               <em>{{ field_scientific_name }}</em>
                       </div>
                    </div>
  </div>";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  72 => 10,  67 => 8,  60 => 4,  55 => 1,);
    }
}
/* {# inline_template_start #}<div class="thumbnail-style">*/
/*                 	<div class="thumbnail-img">*/
/*                               <div class="overflow-hidden">*/
/*                                      {{ field_gallery_image }} */
/*                                </div>*/
/*                         </div>*/
/*                         <div class="text-align-center">*/
/*                         {{ title }}<br>*/
/*                         <div class="latin_name">*/
/*                                <em>{{ field_scientific_name }}</em>*/
/*                        </div>*/
/*                     </div>*/
/*   </div>*/
