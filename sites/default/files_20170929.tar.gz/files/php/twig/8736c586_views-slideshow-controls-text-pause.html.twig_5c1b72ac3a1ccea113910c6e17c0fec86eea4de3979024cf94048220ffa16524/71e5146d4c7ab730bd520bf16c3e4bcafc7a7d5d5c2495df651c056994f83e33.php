<?php

/* themes/shippis/templates/views_slideshow/views-slideshow-controls-text-pause.html.twig */
class __TwigTemplate_222098b362221b5cf93e13d9e9a76894f8fc04f58b0243e2a95ebe825850729d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 2
        echo "  ";
    }

    public function getTemplateName()
    {
        return "themes/shippis/templates/views_slideshow/views-slideshow-controls-text-pause.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  43 => 2,);
    }
}
/* {#<span id="views_slideshow_controls_text_pause_{{ vss_id }}" {{ attributes.addClass(classes) }}>#}*/
/*   {#<a href="#">{{ start_text }}</a>#}*/
/* {#</span>#}*/
/* */
