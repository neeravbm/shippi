<?php

/* themes/shippis/templates/pages/page--gallery-show.html.twig */
class __TwigTemplate_c9b2e328f2e951648f687d663c7b304534e5a7204f427e817ca30fb42f94e984 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("include" => 7);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array('include'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 2
        echo "
<body>

<div class=\"wrapper\">

    ";
        // line 7
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/header.html.twig"), "themes/shippis/templates/pages/page--gallery-show.html.twig", 7)->display($context);
        // line 8
        echo "
    ";
        // line 9
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/breadcrumbs.html.twig"), "themes/shippis/templates/pages/page--gallery-show.html.twig", 9)->display($context);
        // line 10
        echo "
    <div class=\"light\">
        <div class=\"container content\">
            ";
        // line 13
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "help", array()), "html", null, true));
        echo "
            <div class=\"row\">
                ";
        // line 15
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["title_prefix"]) ? $context["title_prefix"] : null), "html", null, true));
        echo "
                ";
        // line 16
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "content", array()), "html", null, true));
        echo "
                ";
        // line 18
        echo "                ";
        // line 19
        echo "                    ";
        // line 20
        echo "                ";
        // line 21
        echo "                ";
        // line 22
        echo "                    ";
        // line 23
        echo "                ";
        // line 24
        echo "            </div>

        </div>
    </div>

</div>


";
        // line 32
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/footer.html.twig"), "themes/shippis/templates/pages/page--gallery-show.html.twig", 32)->display($context);
        // line 33
        echo "

</body>";
    }

    public function getTemplateName()
    {
        return "themes/shippis/templates/pages/page--gallery-show.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  99 => 33,  97 => 32,  87 => 24,  85 => 23,  83 => 22,  81 => 21,  79 => 20,  77 => 19,  75 => 18,  71 => 16,  67 => 15,  62 => 13,  57 => 10,  55 => 9,  52 => 8,  50 => 7,  43 => 2,);
    }
}
/* {# Unify template for displaying a page #}*/
/* */
/* <body>*/
/* */
/* <div class="wrapper">*/
/* */
/*     {% include directory ~ '/partials/header.html.twig' %}*/
/* */
/*     {% include directory ~ '/partials/breadcrumbs.html.twig' %}*/
/* */
/*     <div class="light">*/
/*         <div class="container content">*/
/*             {{ page.help }}*/
/*             <div class="row">*/
/*                 {{ title_prefix }}*/
/*                 {{ page.content }}*/
/*                 {#{{ title_suffix }}#}*/
/*                 {#<div class="text-align-center">#}*/
/*                     {##}*/
/*                 {#</div>#}*/
/*                 {#<div class="col-md-6 col-md-offset-3 col-xs-10 col-xs-offset-1">#}*/
/*                     {##}*/
/*                 {#</div>#}*/
/*             </div>*/
/* */
/*         </div>*/
/*     </div>*/
/* */
/* </div>*/
/* */
/* */
/* {% include directory ~ '/partials/footer.html.twig' %}*/
/* */
/* */
/* </body>*/
