<?php

/* themes/shippis/templates/views_slideshow/views-view-slideshow.html.twig */
class __TwigTemplate_d94b921a90c2fbfd9c1a80ee16bd259341d28ebd3a5c247d2e613a2174ce66d0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("if" => 1);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array('if'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        if ((isset($context["slideshow"]) ? $context["slideshow"] : null)) {
            // line 2
            echo "  <div class=\"skin-";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["skin"]) ? $context["skin"] : null), "html", null, true));
            echo "\">
    ";
            // line 3
            if ((isset($context["top_widget_rendered"]) ? $context["top_widget_rendered"] : null)) {
                // line 4
                echo "      <div class=\"views-slideshow-controls-top clearfix\">
        <div class=\"text-align-center\">
          ";
                // line 6
                echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["top_widget_rendered"]) ? $context["top_widget_rendered"] : null), "html", null, true));
                echo "
        </div>

      </div>
    ";
            }
            // line 11
            echo "
    ";
            // line 12
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["slideshow"]) ? $context["slideshow"] : null), "html", null, true));
            echo "

    ";
            // line 14
            if ((isset($context["bottom_widget_rendered"]) ? $context["bottom_widget_rendered"] : null)) {
                // line 15
                echo "      <div class=\"views-slideshow-controls-bottom clearfix\">
        <div class=\"text-align-center\">
          ";
                // line 17
                echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["bottom_widget_rendered"]) ? $context["bottom_widget_rendered"] : null), "html", null, true));
                echo "
        </div>
      </div>
    ";
            }
            // line 21
            echo "    </div>
";
        }
    }

    public function getTemplateName()
    {
        return "themes/shippis/templates/views_slideshow/views-view-slideshow.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  85 => 21,  78 => 17,  74 => 15,  72 => 14,  67 => 12,  64 => 11,  56 => 6,  52 => 4,  50 => 3,  45 => 2,  43 => 1,);
    }
}
/* {% if slideshow %}*/
/*   <div class="skin-{{ skin }}">*/
/*     {% if top_widget_rendered %}*/
/*       <div class="views-slideshow-controls-top clearfix">*/
/*         <div class="text-align-center">*/
/*           {{ top_widget_rendered }}*/
/*         </div>*/
/* */
/*       </div>*/
/*     {% endif %}*/
/* */
/*     {{ slideshow }}*/
/* */
/*     {% if bottom_widget_rendered %}*/
/*       <div class="views-slideshow-controls-bottom clearfix">*/
/*         <div class="text-align-center">*/
/*           {{ bottom_widget_rendered }}*/
/*         </div>*/
/*       </div>*/
/*     {% endif %}*/
/*     </div>*/
/* {% endif %}*/
/* */
