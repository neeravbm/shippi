<?php

/* themes/unify/templates/page/page--user--login.html.twig */
class __TwigTemplate_4f2aef58643b19b7773cefd57decd76e7583d34877f934f2d97a42bbe20e0d08 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("include" => 7);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array('include'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 2
        echo "
<body>

    <div class=\"wrapper\">

        ";
        // line 7
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/header.html.twig"), "themes/unify/templates/page/page--user--login.html.twig", 7)->display($context);
        // line 8
        echo "
        <div class=\"breadcrumbs\">
            <div class=\"container\">
                <h1 class=\"pull-left\">Login</h1>
            </div>
            ";
        // line 14
        echo "        </div>


            <div class=\"container content\">
                ";
        // line 19
        echo "                ";
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "help", array()), "html", null, true));
        echo "
                <div class=\"row\">
                    <div class=\"col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3\">
                        <div class=\"reg-page\">
                            <div class=\"reg-header\">
                                <h2>Login to your account</h2>
                            </div>
                            ";
        // line 26
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "content", array()), "html", null, true));
        echo "
                            <hr><h4>Create an account</h4>
                            <a class=\"btn-u btn-u-default\" href=\"/user/register\">Register</a>
                        </div>
                    </div>
                </div><!--/row-->
            </div>
    </div>

    ";
        // line 35
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/footer.html.twig"), "themes/unify/templates/page/page--user--login.html.twig", 35)->display($context);
        // line 36
        echo "
</body>";
    }

    public function getTemplateName()
    {
        return "themes/unify/templates/page/page--user--login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  90 => 36,  88 => 35,  76 => 26,  65 => 19,  59 => 14,  52 => 8,  50 => 7,  43 => 2,);
    }
}
/* {# Unify template for displaying user login page #}*/
/* */
/* <body>*/
/* */
/*     <div class="wrapper">*/
/* */
/*         {% include directory ~ '/partials/header.html.twig' %}*/
/* */
/*         <div class="breadcrumbs">*/
/*             <div class="container">*/
/*                 <h1 class="pull-left">Login</h1>*/
/*             </div>*/
/*             {#{{ page.breadcrumb }}#}*/
/*         </div>*/
/* */
/* */
/*             <div class="container content">*/
/*                 {#Status messages and Help Block#}*/
/*                 {{ page.help }}*/
/*                 <div class="row">*/
/*                     <div class="col-md-4 col-md-offset-4 col-sm-6 col-sm-offset-3">*/
/*                         <div class="reg-page">*/
/*                             <div class="reg-header">*/
/*                                 <h2>Login to your account</h2>*/
/*                             </div>*/
/*                             {{ page.content }}*/
/*                             <hr><h4>Create an account</h4>*/
/*                             <a class="btn-u btn-u-default" href="/user/register">Register</a>*/
/*                         </div>*/
/*                     </div>*/
/*                 </div><!--/row-->*/
/*             </div>*/
/*     </div>*/
/* */
/*     {% include directory ~ '/partials/footer.html.twig' %}*/
/* */
/* </body>*/
