<?php

/* themes/unify/templates/page/page--system--404.html.twig */
class __TwigTemplate_5ca22c39118bda8c2da29cc2114325c94d209ac4bdedaf3ed5dbfa5f9e6b21c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("include" => 8);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array('include'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 2
        echo "

<body>

    <div class=\"wrapper\">

        ";
        // line 8
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/header.html.twig"), "themes/unify/templates/page/page--system--404.html.twig", 8)->display($context);
        // line 9
        echo "

        <div class=\"container content\">
            ";
        // line 13
        echo "            ";
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "help", array()), "html", null, true));
        echo "
            <!--Error Block-->
            <div class=\"row\">
                <div class=\"col-md-8 col-md-offset-2\">
                    <div class=\"error-v1\">
                        <span class=\"error-v1-title\">404</span>
                        <span>That’s an error!</span>
                        <p>The requested URL was not found on this server. That’s all we know.</p>
                        <a class=\"btn-u btn-bordered\" href=\"/\">Back Home</a>
                    </div>
                </div>
            </div>
            <!--End Error Block-->
        </div>

    </div>


    ";
        // line 31
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/footer.html.twig"), "themes/unify/templates/page/page--system--404.html.twig", 31)->display($context);
        // line 32
        echo "

</body>";
    }

    public function getTemplateName()
    {
        return "themes/unify/templates/page/page--system--404.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  82 => 32,  80 => 31,  58 => 13,  53 => 9,  51 => 8,  43 => 2,);
    }
}
/* {# Unify template for displaying 404 Page #}*/
/* */
/* */
/* <body>*/
/* */
/*     <div class="wrapper">*/
/* */
/*         {% include directory ~ '/partials/header.html.twig' %}*/
/* */
/* */
/*         <div class="container content">*/
/*             {#Status messages and Help Block#}*/
/*             {{ page.help }}*/
/*             <!--Error Block-->*/
/*             <div class="row">*/
/*                 <div class="col-md-8 col-md-offset-2">*/
/*                     <div class="error-v1">*/
/*                         <span class="error-v1-title">404</span>*/
/*                         <span>That’s an error!</span>*/
/*                         <p>The requested URL was not found on this server. That’s all we know.</p>*/
/*                         <a class="btn-u btn-bordered" href="/">Back Home</a>*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*             <!--End Error Block-->*/
/*         </div>*/
/* */
/*     </div>*/
/* */
/* */
/*     {% include directory ~ '/partials/footer.html.twig' %}*/
/* */
/* */
/* </body>*/
