<?php

/* themes/shippis/templates/block/block--system-branding-block.html.twig */
class __TwigTemplate_8d614e8439babdaf55435db55bb2a3153662bf6ab5850df64a3238c220f98afd extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("block.html.twig", "themes/shippis/templates/block/block--system-branding-block.html.twig", 1);
        $this->blocks = array(
            'content' => array($this, 'block_content'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "block.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("if" => 20);
        $filters = array("t" => 22);
        $functions = array("path" => 22);

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array('if'),
                array('t'),
                array('path')
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 16
    public function block_content($context, array $blocks = array())
    {
        // line 17
        echo "  <div class=\"container\">
    <div class=\"row margin-top-10 margin-bottom-10\">
      <div class=\"logo_center\">
        ";
        // line 20
        if ((isset($context["site_logo"]) ? $context["site_logo"] : null)) {
            // line 21
            echo "          ";
            // line 22
            echo "          <a href=\"";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->renderVar($this->env->getExtension('drupal_core')->getPath("<front>")));
            echo "\" title=\"";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->renderVar(t("Home")));
            echo "\" rel=\"home\" class=\"\">
            <img src=\"";
            // line 23
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["site_logo"]) ? $context["site_logo"] : null), "html", null, true));
            echo "\" alt=\"";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->renderVar(t("Home")));
            echo "\" />
          </a>
        ";
        }
        // line 26
        echo "
        ";
        // line 27
        if ((isset($context["site_name"]) ? $context["site_name"] : null)) {
            // line 28
            echo "          <h1><a href=\"";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->renderVar($this->env->getExtension('drupal_core')->getPath("<front>")));
            echo "\" title=\"";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->renderVar(t("Home")));
            echo "\" rel=\"home\">";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["site_name"]) ? $context["site_name"] : null), "html", null, true));
            echo "</a></h1>
        ";
        }
        // line 30
        echo "
        ";
        // line 31
        if ((isset($context["site_slogan"]) ? $context["site_slogan"] : null)) {
            // line 32
            echo "          <div class=\"site-slogan\">
            <h3>
              ";
            // line 35
            echo "              ";
            echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["site_slogan"]) ? $context["site_slogan"] : null), "html", null, true));
            echo "
            </h3>
          </div>
        ";
        }
        // line 39
        echo "
        ";
        // line 41
        echo "      </div>

    </div>
  </div>

";
    }

    public function getTemplateName()
    {
        return "themes/shippis/templates/block/block--system-branding-block.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  114 => 41,  111 => 39,  103 => 35,  99 => 32,  97 => 31,  94 => 30,  84 => 28,  82 => 27,  79 => 26,  71 => 23,  64 => 22,  62 => 21,  60 => 20,  55 => 17,  52 => 16,  11 => 1,);
    }
}
/* {% extends "block.html.twig" %}*/
/* {#*/
/* /***/
/*  * @file*/
/*  * Theme override for a branding block.*/
/*  **/
/*  * Each branding element variable (logo, name, slogan) is only available if*/
/*  * enabled in the block configuration.*/
/*  **/
/*  * Available variables:*/
/*  * - site_logo: Logo for site as defined in Appearance or theme settings.*/
/*  * - site_name: Name for site as defined in Site information settings.*/
/*  * - site_slogan: Slogan for site as defined in Site information settings.*/
/*  *//* */
/* #}*/
/* {% block content %}*/
/*   <div class="container">*/
/*     <div class="row margin-top-10 margin-bottom-10">*/
/*       <div class="logo_center">*/
/*         {% if site_logo %}*/
/*           {#<div class="col-xs-8 col-md-4"></div>#}*/
/*           <a href="{{ path('<front>') }}" title="{{ 'Home'|t }}" rel="home" class="">*/
/*             <img src="{{ site_logo }}" alt="{{ 'Home'|t }}" />*/
/*           </a>*/
/*         {% endif %}*/
/* */
/*         {% if site_name %}*/
/*           <h1><a href="{{ path('<front>') }}" title="{{ 'Home'|t }}" rel="home">{{ site_name }}</a></h1>*/
/*         {% endif %}*/
/* */
/*         {% if site_slogan %}*/
/*           <div class="site-slogan">*/
/*             <h3>*/
/*               {#<a href="{{ path('<front>') }}" title="{{ 'Home'|t }}" rel="home">{{ site_slogan }}</a>#}*/
/*               {{ site_slogan }}*/
/*             </h3>*/
/*           </div>*/
/*         {% endif %}*/
/* */
/*         {#<div class="col-xs-12 col-md-8"></div>#}*/
/*       </div>*/
/* */
/*     </div>*/
/*   </div>*/
/* */
/* {% endblock %}*/
/* */
/* */
