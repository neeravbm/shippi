<?php

/* themes/shippis/templates/pages/page--front.html.twig */
class __TwigTemplate_0cd5d64af395b959097fd35bc48b5218bebddddabca1760016d9fe67c73c89a7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("include" => 8);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array('include'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 2
        echo "

<body>

    <div class=\"wrapper\">

        ";
        // line 8
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/header.html.twig"), "themes/shippis/templates/pages/page--front.html.twig", 8)->display($context);
        // line 9
        echo "
        ";
        // line 10
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "featured_second", array()), "html", null, true));
        echo "
        ";
        // line 12
        echo "        <div class=\"light\">
            <div class=\"container content-sm\">

                ";
        // line 16
        echo "                <div class=\"row margin-bottom-30\">

                    <div class=\".col-md-8 .col-md-offset-2 md-margin-bottom-40 margin-right-10 margin-left-10\">
                        ";
        // line 20
        echo "                        ";
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "featured_top", array()), "html", null, true));
        echo "
                    </div>

                </div>

                ";
        // line 26
        echo "                ";
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "help", array()), "html", null, true));
        echo "

                ";
        // line 29
        echo "                ";
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "highlighted", array()), "html", null, true));
        echo "
                ";
        // line 31
        echo "
                ";
        // line 33
        echo "                <div class=\"margin-bottom-30\">
                    ";
        // line 34
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "featured_first", array()), "html", null, true));
        echo "
                </div>

            </div>
        </div>
        ";
        // line 40
        echo "    </div>

    ";
        // line 42
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/footer.html.twig"), "themes/shippis/templates/pages/page--front.html.twig", 42)->display($context);
        // line 43
        echo "
</body>";
    }

    public function getTemplateName()
    {
        return "themes/shippis/templates/pages/page--front.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  110 => 43,  108 => 42,  104 => 40,  96 => 34,  93 => 33,  90 => 31,  85 => 29,  79 => 26,  70 => 20,  65 => 16,  60 => 12,  56 => 10,  53 => 9,  51 => 8,  43 => 2,);
    }
}
/* {# Unify template for displaying frontpage #}*/
/* */
/* */
/* <body>*/
/* */
/*     <div class="wrapper">*/
/* */
/*         {% include directory ~ '/partials/header.html.twig' %}*/
/* */
/*         {{ page.featured_second }}*/
/*         {#Main Container For the Services,Recent Works and Welcome Block#}*/
/*         <div class="light">*/
/*             <div class="container content-sm">*/
/* */
/*                 {#Welcome Block in Content Region#}*/
/*                 <div class="row margin-bottom-30">*/
/* */
/*                     <div class=".col-md-8 .col-md-offset-2 md-margin-bottom-40 margin-right-10 margin-left-10">*/
/*                         {#{{ page.content }}#}*/
/*                         {{ page.featured_top }}*/
/*                     </div>*/
/* */
/*                 </div>*/
/* */
/*                 {#Status messages and Help Block#}*/
/*                 {{ page.help }}*/
/* */
/*                 {#Purchase Block in Highlight Region Starts#}*/
/*                 {{ page.highlighted }}*/
/*                 {#Purchase Block Ends#}*/
/* */
/*                 {#Recent Products View Block in Featured First Region#}*/
/*                 <div class="margin-bottom-30">*/
/*                     {{ page.featured_first }}*/
/*                 </div>*/
/* */
/*             </div>*/
/*         </div>*/
/*         {#End the Main Container#}*/
/*     </div>*/
/* */
/*     {% include directory ~ '/partials/footer.html.twig' %}*/
/* */
/* </body>*/
