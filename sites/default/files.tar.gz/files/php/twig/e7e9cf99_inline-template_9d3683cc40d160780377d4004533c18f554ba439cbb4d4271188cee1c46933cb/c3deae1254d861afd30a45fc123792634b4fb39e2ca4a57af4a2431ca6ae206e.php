<?php

/* {# inline_template_start #}<div class="slideshow-style">
                	<div class="slideshow-img">
                        {{ field_gallery_image }} 
                    </div>
  </div> */
class __TwigTemplate_ccaa2a5b39d2ed25e739592eedd8a7464654ec09e9d503a11be9d3492e29f8d7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<div class=\"slideshow-style\">
                \t<div class=\"slideshow-img\">
                        ";
        // line 3
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["field_gallery_image"]) ? $context["field_gallery_image"] : null), "html", null, true));
        echo " 
                    </div>
  </div>";
    }

    public function getTemplateName()
    {
        return "{# inline_template_start #}<div class=\"slideshow-style\">
                \t<div class=\"slideshow-img\">
                        {{ field_gallery_image }} 
                    </div>
  </div>";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  51 => 3,  47 => 1,);
    }
}
/* {# inline_template_start #}<div class="slideshow-style">*/
/*                 	<div class="slideshow-img">*/
/*                         {{ field_gallery_image }} */
/*                     </div>*/
/*   </div>*/
