<?php

/* themes/shippis/templates/pages/page--contact.html.twig */
class __TwigTemplate_d503655b739ba35ec7a4b038637d3b5a08b076bbbbdc57aaa37386faf3eed6c2 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("include" => 7);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array('include'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 2
        echo "
<body>

    <div class=\"wrapper\">

        ";
        // line 7
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/header.html.twig"), "themes/shippis/templates/pages/page--contact.html.twig", 7)->display($context);
        // line 8
        echo "
        <div class=\"light\">
            <div class=\"container content\">
                ";
        // line 12
        echo "                ";
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "help", array()), "html", null, true));
        echo "
                <div class=\"row margin-bottom-30\">
                    <div class=\"col-md-9 mb-margin-bottom-30\">
                        <div class=\"headline\"><h2>Contact Us</h2></div>
                        ";
        // line 16
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "content", array()), "html", null, true));
        echo "
                        ";
        // line 17
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "featured_top", array()), "html", null, true));
        echo "
                    </div><!--/col-md-9-->
                    <div class=\"col-md-3\">
                        ";
        // line 20
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "sidebar_right", array()), "html", null, true));
        echo "
                    </div>
                </div>
            </div>
        </div>
    </div>


    ";
        // line 28
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/footer.html.twig"), "themes/shippis/templates/pages/page--contact.html.twig", 28)->display($context);
        // line 29
        echo "

</body>";
    }

    public function getTemplateName()
    {
        return "themes/shippis/templates/pages/page--contact.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  88 => 29,  86 => 28,  75 => 20,  69 => 17,  65 => 16,  57 => 12,  52 => 8,  50 => 7,  43 => 2,);
    }
}
/* {# Unify template for displaying contact page #}*/
/* */
/* <body>*/
/* */
/*     <div class="wrapper">*/
/* */
/*         {% include directory ~ '/partials/header.html.twig' %}*/
/* */
/*         <div class="light">*/
/*             <div class="container content">*/
/*                 {#Status messages and Help Block#}*/
/*                 {{ page.help }}*/
/*                 <div class="row margin-bottom-30">*/
/*                     <div class="col-md-9 mb-margin-bottom-30">*/
/*                         <div class="headline"><h2>Contact Us</h2></div>*/
/*                         {{ page.content }}*/
/*                         {{ page.featured_top }}*/
/*                     </div><!--/col-md-9-->*/
/*                     <div class="col-md-3">*/
/*                         {{ page.sidebar_right }}*/
/*                     </div>*/
/*                 </div>*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* */
/* */
/*     {% include directory ~ '/partials/footer.html.twig' %}*/
/* */
/* */
/* </body>*/
