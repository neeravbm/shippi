<?php

/* themes/shippis/partials/footer.html.twig */
class __TwigTemplate_96c38cac8fc60df84f1e167f816c4d88067f784bd3580a12edce7c7edf2a7048 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<div class=\"footer-v1\">
    <div class=\"footer\">
        <div class=\"container\">
            <div class=\"row\">

                <div class=\"other col-md-3 md-margin-bottom-40\">
                    ";
        // line 7
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_first", array()), "html", null, true));
        echo "
                </div>

                <div class=\"col-md-3 md-margin-bottom-40\">
                    ";
        // line 11
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_second", array()), "html", null, true));
        echo "
                </div>

                <div class=\"col-md-3 md-margin-bottom-40\">
                    ";
        // line 15
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_third", array()), "html", null, true));
        echo "
                </div>

                <div class=\"col-md-3 map-img md-margin-bottom-40\">
                    ";
        // line 19
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_fourth", array()), "html", null, true));
        echo "
                </div>

            </div>
        </div>
    </div><!--/footer-->

    <div class=\"copyright\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-md-6\">
                    ";
        // line 30
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_bottom_first", array()), "html", null, true));
        echo "
                </div>

                <!-- Social Links -->
                <div class=\"col-md-6\">
                    ";
        // line 35
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "footer_bottom_second", array()), "html", null, true));
        echo "
                </div>
                <!-- End Social Links -->
            </div>
        </div>
    </div>

</div>
";
    }

    public function getTemplateName()
    {
        return "themes/shippis/partials/footer.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 35,  86 => 30,  72 => 19,  65 => 15,  58 => 11,  51 => 7,  43 => 1,);
    }
}
/* <div class="footer-v1">*/
/*     <div class="footer">*/
/*         <div class="container">*/
/*             <div class="row">*/
/* */
/*                 <div class="other col-md-3 md-margin-bottom-40">*/
/*                     {{ page.footer_first }}*/
/*                 </div>*/
/* */
/*                 <div class="col-md-3 md-margin-bottom-40">*/
/*                     {{ page.footer_second }}*/
/*                 </div>*/
/* */
/*                 <div class="col-md-3 md-margin-bottom-40">*/
/*                     {{ page.footer_third }}*/
/*                 </div>*/
/* */
/*                 <div class="col-md-3 map-img md-margin-bottom-40">*/
/*                     {{ page.footer_fourth }}*/
/*                 </div>*/
/* */
/*             </div>*/
/*         </div>*/
/*     </div><!--/footer-->*/
/* */
/*     <div class="copyright">*/
/*         <div class="container">*/
/*             <div class="row">*/
/*                 <div class="col-md-6">*/
/*                     {{ page.footer_bottom_first }}*/
/*                 </div>*/
/* */
/*                 <!-- Social Links -->*/
/*                 <div class="col-md-6">*/
/*                     {{ page.footer_bottom_second }}*/
/*                 </div>*/
/*                 <!-- End Social Links -->*/
/*             </div>*/
/*         </div>*/
/*     </div>*/
/* */
/* </div>*/
/* */
