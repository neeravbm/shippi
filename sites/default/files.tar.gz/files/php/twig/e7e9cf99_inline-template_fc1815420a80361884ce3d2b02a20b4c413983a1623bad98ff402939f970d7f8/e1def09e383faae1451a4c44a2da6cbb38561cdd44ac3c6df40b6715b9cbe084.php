<?php

/* {# inline_template_start #}<li class="col-md-4 col-sm-6 md-margin-bottom-30">
                    <div class="block-grid-v2-info rounded-bottom">
                    <h3>{{ title }}</h3>
                    <!--<p>{{ field_class_short_description }}</p> --> 
                </div>
            </li> */
class __TwigTemplate_3176a448708e1185750153d866c753019986d1182efae9f2d2826a36e4d7cb43 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array();
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array(),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 1
        echo "<li class=\"col-md-4 col-sm-6 md-margin-bottom-30\">
                    <div class=\"block-grid-v2-info rounded-bottom\">
                    <h3>";
        // line 3
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["title"]) ? $context["title"] : null), "html", null, true));
        echo "</h3>
                    <!--<p>";
        // line 4
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["field_class_short_description"]) ? $context["field_class_short_description"] : null), "html", null, true));
        echo "</p> --> 
                </div>
            </li>";
    }

    public function getTemplateName()
    {
        return "{# inline_template_start #}<li class=\"col-md-4 col-sm-6 md-margin-bottom-30\">
                    <div class=\"block-grid-v2-info rounded-bottom\">
                    <h3>{{ title }}</h3>
                    <!--<p>{{ field_class_short_description }}</p> --> 
                </div>
            </li>";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  56 => 4,  52 => 3,  48 => 1,);
    }
}
/* {# inline_template_start #}<li class="col-md-4 col-sm-6 md-margin-bottom-30">*/
/*                     <div class="block-grid-v2-info rounded-bottom">*/
/*                     <h3>{{ title }}</h3>*/
/*                     <!--<p>{{ field_class_short_description }}</p> --> */
/*                 </div>*/
/*             </li>*/
