<?php

/* themes/shippis/templates/pages/page.html.twig */
class __TwigTemplate_8b70dfce3e88fe24da9bee26022e4762410228e5b9cda54bb3b39075f41e69ca extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $tags = array("include" => 7);
        $filters = array();
        $functions = array();

        try {
            $this->env->getExtension('sandbox')->checkSecurity(
                array('include'),
                array(),
                array()
            );
        } catch (Twig_Sandbox_SecurityError $e) {
            $e->setTemplateFile($this->getTemplateName());

            if ($e instanceof Twig_Sandbox_SecurityNotAllowedTagError && isset($tags[$e->getTagName()])) {
                $e->setTemplateLine($tags[$e->getTagName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFilterError && isset($filters[$e->getFilterName()])) {
                $e->setTemplateLine($filters[$e->getFilterName()]);
            } elseif ($e instanceof Twig_Sandbox_SecurityNotAllowedFunctionError && isset($functions[$e->getFunctionName()])) {
                $e->setTemplateLine($functions[$e->getFunctionName()]);
            }

            throw $e;
        }

        // line 2
        echo "
<body>

    <div class=\"wrapper\">

        ";
        // line 7
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/header.html.twig"), "themes/shippis/templates/pages/page.html.twig", 7)->display($context);
        // line 8
        echo "
        ";
        // line 9
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/breadcrumbs.html.twig"), "themes/shippis/templates/pages/page.html.twig", 9)->display($context);
        // line 10
        echo "
        <div class=\"light\">
            <div class=\"container content\">
                ";
        // line 13
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "help", array()), "html", null, true));
        echo "
                ";
        // line 14
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["title_prefix"]) ? $context["title_prefix"] : null), "html", null, true));
        echo "
                ";
        // line 15
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, $this->getAttribute((isset($context["page"]) ? $context["page"] : null), "content", array()), "html", null, true));
        echo "
                ";
        // line 16
        echo $this->env->getExtension('sandbox')->ensureToStringAllowed($this->env->getExtension('drupal_core')->escapeFilter($this->env, (isset($context["title_suffix"]) ? $context["title_suffix"] : null), "html", null, true));
        echo "

            </div>
        </div>

    </div>


    ";
        // line 24
        $this->loadTemplate(((isset($context["directory"]) ? $context["directory"] : null) . "/partials/footer.html.twig"), "themes/shippis/templates/pages/page.html.twig", 24)->display($context);
        // line 25
        echo "

</body>";
    }

    public function getTemplateName()
    {
        return "themes/shippis/templates/pages/page.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  87 => 25,  85 => 24,  74 => 16,  70 => 15,  66 => 14,  62 => 13,  57 => 10,  55 => 9,  52 => 8,  50 => 7,  43 => 2,);
    }
}
/* {# Unify template for displaying a page #}*/
/* */
/* <body>*/
/* */
/*     <div class="wrapper">*/
/* */
/*         {% include directory ~ '/partials/header.html.twig' %}*/
/* */
/*         {% include directory ~ '/partials/breadcrumbs.html.twig' %}*/
/* */
/*         <div class="light">*/
/*             <div class="container content">*/
/*                 {{ page.help }}*/
/*                 {{ title_prefix }}*/
/*                 {{ page.content }}*/
/*                 {{ title_suffix }}*/
/* */
/*             </div>*/
/*         </div>*/
/* */
/*     </div>*/
/* */
/* */
/*     {% include directory ~ '/partials/footer.html.twig' %}*/
/* */
/* */
/* </body>*/
